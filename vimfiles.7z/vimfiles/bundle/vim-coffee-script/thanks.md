Thanks to the following contributors:

    Brian Egan (3):
          Adding compile functionality to the ftplugin. Must be enabled in .vimrc
          Updating the readme with compilation instructions
          Updating bad header in readme to make instructions easier to read

    Chris Hoffman (3):
          Add new keywoards from, to, and do
          Highlight the - in negative integers
          Add here regex highlighting, increase fold level for here docs

    Karl Guertin (1):
          Cakefiles are coffeescript

    Simon Lipp (1):
          Trailing spaces are not error on lines containing only spaces

And thanks to anyone who files or has filed a bug report.
